function function() {
  document.getElementById(div).style.animationPlayState = paused;
}

