/*ontouchstart*/
function someFunction() {
  document.getElementById('something').innerHTML = "Hello World";
}
/*ontouchmove*/
function anotherFunction() {
  document.getElementById('something2').innerHTML = "Hello Again";
}
/*ontouchend*/
function thirdFunction() {
  document.getElementById('something3').innerHTML = "HELLO";
}
/*ontouchcancel*/
function fourthFunction() {
  document.getElementById('something4').innerHTML = "HELLO AGAIN";
}
