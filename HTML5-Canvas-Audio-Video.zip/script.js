var canvas = document.getElementById("canvas");
var ctx = canvas.getContext("2d");
ctx.beginPath();
ctx.arc(150, 100, 70, 20, 360);
ctx.stroke();