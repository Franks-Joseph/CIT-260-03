function prop() {
document.getElementById("blue").style.width = "100px";
document.getElementById("blue").style.height = "100px";
document.getElementById("blue").style.border = "solid 2px black";
}